package tls

import (
	"context"
	"crypto/rand"
	cryptotls "crypto/tls"
	"crypto/x509"
	"encoding/pem"
	"math/big"
	"net"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/sagernet/sing-box/log"
	"github.com/sagernet/sing-box/option"
)

func TestNativeProvisioningCertificateFileWatcher(t *testing.T) {
	directory := t.TempDir()
	certPath, keyPath := filepath.Join(directory, "fullchain.pem"), filepath.Join(directory, "privkey.pem")
	// GenerateKeyPair produces synthetic, local-only certificates; this case keeps the private key.
	first, err := GenerateKeyPair(nil, nil, time.Now, "localhost")
	if err != nil {
		t.Fatal(err)
	}
	keyDER, err := x509.MarshalPKCS8PrivateKey(first.PrivateKey)
	if err != nil {
		t.Fatal(err)
	}
	write := func(path string, content []byte) {
		t.Helper()
		if err := os.WriteFile(path, content, 0600); err != nil {
			t.Fatal(err)
		}
	}
	write(certPath, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: first.Certificate[0]}))
	write(keyPath, pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: keyDER}))
	server, err := NewSTDServer(context.Background(), log.NewNOPFactory().Logger(), option.InboundTLSOptions{
		Enabled: true, CertificatePath: certPath, KeyPath: keyPath,
	})
	if err != nil {
		t.Fatal(err)
	}
	if err := server.Start(); err != nil {
		t.Fatal(err)
	}
	defer server.Close()
	if server.(*STDServerConfig).watcher == nil {
		t.Fatal("no active file watcher")
	}
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer listener.Close()
	go func() {
		for {
			conn, e := listener.Accept()
			if e != nil {
				return
			}
			go func() {
				defer conn.Close()
				secure, _ := server.Server(conn)
				buffer := make([]byte, 32)
				for {
					n, e := secure.Read(buffer)
					if e != nil {
						return
					}
					if _, e = secure.Write(buffer[:n]); e != nil {
						return
					}
				}
			}()
		}
	}()
	dial := func() (*cryptotls.Conn, error) {
		return cryptotls.DialWithDialer(&net.Dialer{Timeout: time.Second}, "tcp", listener.Addr().String(), &cryptotls.Config{InsecureSkipVerify: true})
	}
	established, err := dial()
	if err != nil {
		t.Fatal(err)
	}
	defer established.Close()
	initial := established.ConnectionState().PeerCertificates[0].SerialNumber
	leaf, err := x509.ParseCertificate(first.Certificate[0])
	if err != nil {
		t.Fatal(err)
	}
	leaf.SerialNumber = new(big.Int).Add(initial, big.NewInt(1))
	key := first.PrivateKey
	publicKey := leaf.PublicKey
	updated, err := x509.CreateCertificate(rand.Reader, leaf, leaf, publicKey, key)
	if err != nil {
		t.Fatal(err)
	}
	temporary := filepath.Join(directory, "staged.pem")
	write(temporary, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: updated}))
	if err := os.Rename(temporary, certPath); err != nil {
		t.Fatal(err)
	}
	deadline := time.Now().Add(5 * time.Second)
	for {
		newer, e := dial()
		if e != nil {
			t.Fatal(e)
		}
		serial := newer.ConnectionState().PeerCertificates[0].SerialNumber
		newer.Close()
		if serial.Cmp(initial) != 0 {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("watcher did not reload staged certificate")
		}
		time.Sleep(25 * time.Millisecond)
	}
	established.SetDeadline(time.Now().Add(time.Second))
	if _, err = established.Write([]byte("still-live")); err != nil {
		t.Fatal(err)
	}
	echoed := make([]byte, 10)
	n, err := established.Read(echoed)
	if err != nil || string(echoed[:n]) != "still-live" {
		t.Fatalf("existing flow lost: %q %v", echoed[:n], err)
	}
	// A key rotation briefly stages an unmatched pair. The active TLS config must
	// keep the prior certificate until the second file completes the validated pair.
	rotated, err := GenerateKeyPair(nil, nil, time.Now, "localhost")
	if err != nil {
		t.Fatal(err)
	}
	rotatedDER, err := x509.MarshalPKCS8PrivateKey(rotated.PrivateKey)
	if err != nil {
		t.Fatal(err)
	}
	stagedKey := filepath.Join(directory, "staged-key.pem")
	write(stagedKey, pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: rotatedDER}))
	if err := os.Rename(stagedKey, keyPath); err != nil {
		t.Fatal(err)
	}
	time.Sleep(250 * time.Millisecond)
	unchanged, err := dial()
	if err != nil {
		t.Fatal(err)
	}
	if unchanged.ConnectionState().PeerCertificates[0].SerialNumber.Cmp(leaf.SerialNumber) != 0 {
		t.Fatal("incomplete pair changed active certificate")
	}
	unchanged.Close()
	write(temporary, pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: rotated.Certificate[0]}))
	if err := os.Rename(temporary, certPath); err != nil {
		t.Fatal(err)
	}
	rotatedLeaf, err := x509.ParseCertificate(rotated.Certificate[0])
	if err != nil {
		t.Fatal(err)
	}
	deadline = time.Now().Add(5 * time.Second)
	for {
		newer, e := dial()
		if e != nil {
			t.Fatal(e)
		}
		serial := newer.ConnectionState().PeerCertificates[0].SerialNumber
		newer.Close()
		if serial.Cmp(rotatedLeaf.SerialNumber) == 0 {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("rotated pair did not reload")
		}
		time.Sleep(25 * time.Millisecond)
	}
	established.SetDeadline(time.Now().Add(time.Second))
	if _, err = established.Write([]byte("after-rotate")); err != nil {
		t.Fatal(err)
	}
	echoed = make([]byte, 12)
	n, err = established.Read(echoed)
	if err != nil || string(echoed[:n]) != "after-rotate" {
		t.Fatalf("rotation lost existing flow: %q %v", echoed[:n], err)
	}
	t.Log("actual watcher reload: same-key renewal and rotated certificate/key observed by fresh TLS handshakes; incomplete pair retains old config; established TLS echo continues; no core restart")
}
