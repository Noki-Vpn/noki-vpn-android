//go:build with_v2ray_api

package box_test

import (
	"context"
	"path/filepath"
	"testing"

	box "github.com/sagernet/sing-box"
	"github.com/sagernet/sing-box/adapter"
	"github.com/sagernet/sing-box/include"
	"github.com/sagernet/sing-box/option"
	"github.com/sagernet/sing/service"
)

func TestNativeControlSocketConstructedWithoutTCPListener(t *testing.T) {
	ctx := service.ContextWithDefaultRegistry(include.Context(context.Background()))
	instance, err := box.New(box.Options{Context: ctx, Options: option.Options{
		Experimental: &option.ExperimentalOptions{V2RayAPI: &option.V2RayAPIOptions{
			ControlSocket: filepath.Join(t.TempDir(), "control.sock"),
			Stats:         &option.V2RayStatsServiceOptions{Enabled: true, AllUsers: true},
		}},
	}})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { instance.Close() })
	if service.FromContext[adapter.V2RayServer](ctx) == nil {
		t.Fatal("Box omitted configured Unix control server")
	}
}
