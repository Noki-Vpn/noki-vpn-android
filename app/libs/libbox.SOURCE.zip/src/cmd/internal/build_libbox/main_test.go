package main

import (
	"slices"
	"testing"
)

func TestNokiNVBuildProfile(t *testing.T) {
	tags, err := tagsForProfile("nokinv")
	if err != nil {
		t.Fatal(err)
	}
	for _, tag := range []string{"with_gvisor", "with_quic", "with_wireguard", "with_utls"} {
		if !slices.Contains(tags, tag) {
			t.Fatalf("missing %s", tag)
		}
	}
	for _, tag := range []string{"debug", "with_naive_outbound", "with_tailscale", "with_maybenot"} {
		if slices.Contains(tags, tag) {
			t.Fatalf("unexpected %s", tag)
		}
	}
	if _, err = tagsForProfile("invalid"); err == nil {
		t.Fatal("unknown build profile accepted")
	}
}

func TestMaybenotBuildIsExplicit(t *testing.T) {
	ordinary, err := tagsForProfile("nokinv")
	if err != nil {
		t.Fatal(err)
	}
	optional, err := tagsForProfile("nokinv-maybenot")
	if err != nil {
		t.Fatal(err)
	}
	if !slices.Equal(optional[:len(optional)-1], ordinary) || optional[len(optional)-1] != "with_maybenot" {
		t.Fatal("optional native profile changed the ordinary core features")
	}
	optional[0] = "mutated"
	fresh, err := tagsForProfile("nokinv")
	if err != nil || !slices.Equal(fresh, ordinary) {
		t.Fatal("build profile tags share mutable state")
	}
}
