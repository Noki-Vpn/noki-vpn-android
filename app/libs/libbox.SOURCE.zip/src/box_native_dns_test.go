//go:build with_v2ray_api

package box_test

import (
	"context"
	"encoding/binary"
	"fmt"
	"io"
	"net"
	"sync/atomic"
	"testing"
	"time"

	mDNS "github.com/miekg/dns"
	box "github.com/sagernet/sing-box"
	"github.com/sagernet/sing-box/adapter"
	"github.com/sagernet/sing-box/experimental/v2rayapi"
	"github.com/sagernet/sing-box/include"
	"github.com/sagernet/sing-box/log"
	"github.com/sagernet/sing-box/option"
	libvless "github.com/sagernet/sing-vmess/vless"
	"github.com/sagernet/sing/common/json"
	M "github.com/sagernet/sing/common/metadata"
	"github.com/sagernet/sing/service"
)

func TestNativeBoxDNSHijackCountsRevokeDrain(t *testing.T) {
	for _, testCase := range []struct{ network, prefix string }{{"tcp", ""}, {"udp", ""}, {"tcp", `{"action":"sniff"},`}, {"udp", `{"action":"sniff"},`}} {
		t.Run(testCase.network+fmt.Sprint(testCase.prefix != ""), func(t *testing.T) {
			network := testCase.network
			upstream, err := net.ListenPacket("udp", "127.0.0.1:0")
			if err != nil {
				t.Fatal(err)
			}
			var accepted atomic.Int32
			held, release := make(chan struct{}, 1), make(chan struct{})
			released := false
			defer func() {
				if !released {
					close(release)
				}
			}()
			server := &mDNS.Server{PacketConn: upstream, Handler: mDNS.HandlerFunc(func(w mDNS.ResponseWriter, request *mDNS.Msg) {
				accepted.Add(1)
				if request.Question[0].Name == "holded.dns.test." {
					select {
					case held <- struct{}{}:
					default:
					}
					<-release
				}
				response := new(mDNS.Msg)
				response.SetReply(request)
				response.Answer = []mDNS.RR{&mDNS.A{Hdr: mDNS.RR_Header{Name: request.Question[0].Name, Rrtype: mDNS.TypeA, Class: mDNS.ClassINET, Ttl: 1}, A: net.IPv4(198, 51, 100, 42)}}
				w.WriteMsg(response)
			})}
			go server.ActivateAndServe()
			t.Cleanup(func() { server.Shutdown(); upstream.Close() })
			reservation, err := net.Listen("tcp", "127.0.0.1:0")
			if err != nil {
				t.Fatal(err)
			}
			address := reservation.Addr().String()
			port := reservation.Addr().(*net.TCPAddr).Port
			reservation.Close()
			ctx := service.ContextWithDefaultRegistry(include.Context(context.Background()))
			configuration := fmt.Sprintf(`{"log":{"disabled":true},"dns":{"servers":[{"type":"udp","tag":"local","server":"127.0.0.1","server_port":%d}],"final":"local","disable_cache":true},"inbounds":[{"type":"vless","tag":"native-dns","listen":"127.0.0.1","listen_port":%d,"users":[{"name":"A","uuid":"11111111-1111-4111-8111-111111111111"},{"name":"B","uuid":"22222222-2222-4222-8222-222222222222"}]}],"outbounds":[{"type":"direct","tag":"direct"}],"route":{"rules":[%s{"port":53,"action":"hijack-dns"}],"final":"direct"},"experimental":{"v2ray_api":{"listen":"127.0.0.1:0","stats":{"enabled":true,"all_users":true,"inbounds":["native-dns"],"outbounds":["direct"]}}}}`, upstream.LocalAddr().(*net.UDPAddr).Port, port, testCase.prefix)
			options, err := json.UnmarshalExtendedContext[option.Options](ctx, []byte(configuration))
			if err != nil {
				t.Fatal(err)
			}
			instance, err := box.New(box.Options{Context: ctx, Options: options})
			if err != nil {
				t.Fatal(err)
			}
			if err = instance.Start(); err != nil {
				instance.Close()
				t.Fatal(err)
			}
			t.Cleanup(func() { instance.Close() })
			stats := service.FromContext[adapter.V2RayServer](ctx).StatsService().(*v2rayapi.StatsService)
			getCount := func(prefix, direction string) int64 {
				result, e := stats.GetStats(ctx, &v2rayapi.GetStatsRequest{Name: prefix + ">>>traffic>>>" + direction})
				if e != nil {
					return 0
				}
				return result.Stat.Value
			}
			inbound, _ := instance.Inbound().Get("native-dns")
			users := inbound.(adapter.UserUpdater)
			dial := func(id string) (net.Conn, *libvless.PacketConn) {
				t.Helper()
				raw, e := net.DialTimeout("tcp", address, time.Second)
				if e != nil {
					t.Fatal(e)
				}
				t.Cleanup(func() { raw.Close() })
				raw.SetDeadline(time.Now().Add(time.Second))
				client, e := libvless.NewClient(id, "", log.NewNOPFactory().Logger())
				if e != nil {
					t.Fatal(e)
				}
				if network == "udp" {
					packet, e := client.DialEarlyPacketConn(raw, M.ParseSocksaddr("198.18.0.1:53"))
					if e != nil {
						t.Fatal(e)
					}
					return packet, packet
				}
				conn, e := client.DialConn(raw, M.ParseSocksaddr("198.18.0.1:53"))
				if e != nil {
					t.Fatal(e)
				}
				return conn, nil
			}
			query := func(conn net.Conn, packet *libvless.PacketConn, names ...string) (int64, int64, error) {
				conn.SetDeadline(time.Now().Add(time.Second))
				message := new(mDNS.Msg)
				name := "native.dns.test."
				if len(names) != 0 {
					name = names[0]
				}
				message.SetQuestion(name, mDNS.TypeA)
				payload, _ := message.Pack()
				var response []byte
				var e error
				if packet == nil {
					frame := make([]byte, 2+len(payload))
					binary.BigEndian.PutUint16(frame, uint16(len(payload)))
					copy(frame[2:], payload)
					_, e = conn.Write(frame)
					if e == nil {
						var length uint16
						e = binary.Read(conn, binary.BigEndian, &length)
						if e == nil {
							response = make([]byte, int(length))
							_, e = io.ReadFull(conn, response)
						}
					}
				} else {
					_, e = packet.Write(payload)
					if e == nil {
						response = make([]byte, 65535)
						var size int
						size, e = packet.Read(response)
						response = response[:size]
					}
				}
				if e != nil {
					return 0, 0, e
				}
				answer := new(mDNS.Msg)
				if e = answer.Unpack(response); e != nil {
					return 0, 0, e
				}
				if len(answer.Answer) != 1 || !answer.Answer[0].(*mDNS.A).A.Equal(net.IPv4(198, 51, 100, 42)) {
					return 0, 0, fmt.Errorf("unexpected DNS answer")
				}
				framing := 0
				if packet == nil {
					framing = 2
				}
				return int64(len(payload) + framing), int64(len(response) + framing), nil
			}
			a, ap := dial("11111111-1111-4111-8111-111111111111")
			b, bp := dial("22222222-2222-4222-8222-222222222222")
			tx, rx, err := query(a, ap)
			if err != nil {
				t.Fatal(err)
			}
			if _, _, err = query(b, bp); err != nil {
				t.Fatal(err)
			}
			checkCounts := func(user string, uploads, downloads int64) {
				t.Helper()
				deadline := time.Now().Add(100 * time.Millisecond)
				for getCount("user>>>"+user, "downlink") < downloads*rx && time.Now().Before(deadline) {
					time.Sleep(time.Millisecond)
				}
				if got := getCount("user>>>"+user, "uplink"); got != uploads*tx {
					t.Errorf("%s DNS upload=%d want %d", user, got, uploads*tx)
				}
				if got := getCount("user>>>"+user, "downlink"); got != downloads*rx {
					t.Errorf("%s DNS download=%d want %d", user, got, downloads*rx)
				}
			}
			checkCounts("A", 1, 1)
			checkCounts("B", 1, 1)
			if getCount("outbound>>>direct", "uplink") != 0 || getCount("outbound>>>direct", "downlink") != 0 {
				t.Error("internal DNS charged to unused direct outbound")
			}
			pending := make(chan error, 1)
			go func() { _, _, e := query(a, ap, "holded.dns.test."); pending <- e }()
			select {
			case <-held:
			case <-time.After(time.Second):
				t.Fatal("pending A DNS query did not reach upstream")
			}
			removeCtx, cancel := context.WithTimeout(ctx, time.Second)
			defer cancel()
			if err = users.RemoveUser(removeCtx, "A"); err != nil {
				t.Fatal(err)
			}
			select {
			case pendingErr := <-pending:
				if pendingErr == nil {
					t.Error("removed A pending DNS query completed")
				}
			case <-time.After(time.Second):
				t.Fatal("removed A pending DNS query not canceled")
			}
			baseline := accepted.Load()
			if _, _, err = query(a, ap); err == nil {
				t.Error("removed A existing DNS conn survived")
			}
			aFresh, aFreshPacket := dial("11111111-1111-4111-8111-111111111111")
			if _, _, err = query(aFresh, aFreshPacket); err == nil {
				t.Error("removed A fresh DNS credential accepted")
			}
			if accepted.Load() != baseline {
				t.Error("removed A reached DNS upstream")
			}
			close(release)
			released = true
			if _, _, err = query(b, bp); err != nil {
				t.Fatal("B existing DNS connection lost:", err)
			}
			checkCounts("A", 2, 1)
			checkCounts("B", 2, 2)
			if err = users.DrainUsers(removeCtx); err != nil {
				t.Fatal(err)
			}
			baseline = accepted.Load()
			if _, _, err = query(b, bp); err == nil {
				t.Error("drained B DNS connection survived")
			}
			if accepted.Load() != baseline {
				t.Error("drained B reached DNS upstream")
			}
			checkCounts("A", 2, 1)
			checkCounts("B", 2, 2)
			time.Sleep(20 * time.Millisecond)
			checkCounts("A", 2, 1)
			checkCounts("B", 2, 2)
		})
	}
}
